#include<iostream>
#include<string>
using namespace std;

class Entity
{
private:
	int a,b;

public:
	int get() const
	{
		return m_x
	}

};