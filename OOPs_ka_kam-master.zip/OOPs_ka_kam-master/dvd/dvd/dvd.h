#include<iostream>
#include<string.h>
#include<string>
using namespace std;
class dvd
{
private:
	 string name;
	int cost;

public:
	dvd()
	{
	this->cost=0;
	this->
	}
}