#include<iostream>
using namespace std;


class DVDD
{
private:
	string name;
	int cost;

public:
	DVDD()
	{
	
	}

	DVDD(string name, int cost)
	{
	this->name=name;
	this->cost=cost;
	}


};